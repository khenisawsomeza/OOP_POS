package com.mycompany.pos.ui.cashier.components;

import com.mycompany.pos.config.AppConstants;
import com.mycompany.pos.config.UIColors;
import com.mycompany.pos.ui.Utils;
import java.awt.*;
import javax.swing.*;

public class HeaderPanel extends JPanel {
    
    public HeaderPanel() {
        initializeHeader();
    }
    
    //Initialize the header panel with all components
    private void initializeHeader() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(AppConstants.ITEMS_PANEL_WIDTH, AppConstants.HEADER_HEIGHT));
        setBackground(UIColors.HEADER_BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(0, 20, 0 ,20));
        
        // Add logo on the right
        addLogoSection();
        
        // Add navigation buttons on the left
        addNavigationSection();
    }
    
    //Create and add the logo section
    private void addLogoSection() {
        JLabel companyLogoLabel = Utils.createIcon(AppConstants.LOGO_WIDTH, AppConstants.LOGO_HEIGHT, SwingConstants.CENTER, SwingConstants.CENTER, AppConstants.LOGO_IMAGE);
        add(companyLogoLabel, BorderLayout.EAST);
    }
    
    //Create and add the navigation buttons section
    private void addNavigationSection() {
        JPanel navigationButtonsPanel = Utils.createPanel(new FlowLayout(FlowLayout.LEFT, 15, 10), new Dimension(700, AppConstants.HEADER_HEIGHT)
        );
        
        JButton searchButton =  Utils.createIconButton(30, 30, AppConstants.SEARCH_ICON);
        navigationButtonsPanel.add(searchButton);
        
        JTextField searchField = Utils.createTextField("Search Item");
        navigationButtonsPanel.add(searchField);
        searchField.setVisible(false);
                    
        boolean[] searchFlag = {false};
        searchButton.addActionListener(e -> {
            searchFlag[0] = !searchFlag[0]; // toggle
            searchField.setVisible(searchFlag[0]);
            navigationButtonsPanel.revalidate();
            navigationButtonsPanel.repaint();
        });  
        
        add(navigationButtonsPanel, BorderLayout.WEST);
    }
    
}
