/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos.ui.cashier;

import com.mycompany.pos.config.AppConstants;
import com.mycompany.pos.model.Cart;
import com.mycompany.pos.ui.cashier.components.CartPanel;
import com.mycompany.pos.ui.cashier.components.ItemsPanel;
import java.awt.*;
import javax.swing.*;

public class cashierGUI extends JFrame {
    private Cart cart;
    private CartPanel cartPanel;
    private ItemsPanel itemsPanel;
    
    public cashierGUI() {
        // Initialize data models
        initializeDataModels();
        
        // Setup main window
        setupMainWindow();
        
        // Create and add components
        createComponents();
        
        // Make window visible
        setVisible(true);
    }
    
    // Initialize data models (cart, items, etc.)
    private void initializeDataModels() {
        cart = new Cart();
    }
    
    // Setup main window properties
    private void setupMainWindow() {
        setSize(AppConstants.WINDOW_WIDTH, AppConstants.WINDOW_HEIGHT);
        setMinimumSize(new Dimension(AppConstants.MIN_WINDOW_WIDTH, AppConstants.MIN_WINDOW_HEIGHT));
        setMaximumSize(new Dimension(AppConstants.MAX_WINDOW_WIDTH, AppConstants.MAX_WINDOW_HEIGHT));
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle(AppConstants.APP_TITLE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
    }
    
    //Create and add main components to the window
    private void createComponents() {
        // Create cart panel (right side)
        cartPanel = new CartPanel(cart);
        add(cartPanel, BorderLayout.EAST);
        
        // Create items panel (left side)
        itemsPanel = new ItemsPanel(cart, cartPanel);
        add(itemsPanel, BorderLayout.CENTER);
    }
    
    //Get the cart instance (if needed)
    public Cart getCart() {
        return cart;
    }
    
    //Get the cart panel component (if needed)
    public CartPanel getCartPanel() {
        return cartPanel;
    }
    
    //Get the items panel component (if needed)
    public ItemsPanel getItemsPanel() {
        return itemsPanel;
    }
    

}
