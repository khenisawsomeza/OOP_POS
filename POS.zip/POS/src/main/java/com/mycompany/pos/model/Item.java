package com.mycompany.pos.model;

import java.io.File;
import javax.swing.ImageIcon;

public class Item {
    private String id;
    private String name;
    private double price;
    private String category;
    private boolean available;
    private ImageIcon picture;
    
    public Item(){
        this.name = "";
        this.price = 0.00;
        this.picture = new ImageIcon("nofile.jpg");
    }
    
    public Item(String id, String name, double price, String category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
        this.available = true;
        String folderPath = "src\\main\\java\\com\\mycompany\\pos\\resources\\foodPics\\";
        String filePath = folderPath + name.toLowerCase() + ".png";
        File itemImg = new File(filePath);
        this.picture = itemImg.exists() ? new ImageIcon(filePath) : new ImageIcon(folderPath+"nofile.jpg");
    }
    
    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }
    public boolean isAvailable() { return available; }
    public ImageIcon getPicture() { return picture; }
    
    // Setters
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }
    public void setCategory(String category) { this.category = category; }
    public void setAvailable(boolean available) { this.available = available; }
    
    // Helper methods
    public String getFormattedPrice() {
        return String.format("$%.2f", price);
    }
    
}
