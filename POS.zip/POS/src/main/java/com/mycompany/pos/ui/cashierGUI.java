/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos.ui;

import com.mycompany.pos.ui.Utils;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

/**
 *
 * @author Khenyshi
 */
public class cashierGUI extends JFrame {
    JFrame frame = new JFrame();
    JPanel cartCenterSection;
    
    public cashierGUI(){
        frame.setSize(1280, 720);
        frame.setMinimumSize(new Dimension(1280, 720));
        frame.setMaximumSize(new Dimension(1920, 1080));   
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Cashier");
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        
        Border border = BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0x808080));
        Border spacer1 = Utils.createSpacer(0,20,0,20);
        Border spacer2 = Utils.createSpacer(0,30,0,30);
        Border spacer3 = Utils.createSpacer(10,30,10,30);
        Border spacer4 = Utils.createSpacer(10,40,10,40);
        
        //right side of frame (checkout and cart group)
        JPanel cartPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 1080), new Color(0xF3F4F6));
        cartPanel.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(0x808080)));
        frame.add(cartPanel, BorderLayout.EAST);
        
            //checkout top group (Top Details)
            JPanel cartTopSection = Utils.createPanel(new BorderLayout(), new Dimension(500, 80));
            cartPanel.add(cartTopSection, BorderLayout.NORTH);
            
                //header section (Title, button etc)
                JPanel cartTitlePanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 50));
                cartTitlePanel.setBorder(border);
                cartTopSection.add(cartTitlePanel, BorderLayout.NORTH);
                    JPanel cartTitleContent = Utils.createPanel(new BorderLayout(), new Dimension(500, 50));
                    cartTitleContent.setBorder(spacer1);
                    cartTitlePanel.add(cartTitleContent, BorderLayout.CENTER);
                        JLabel cartTitleLabel = Utils.createLabel("Cart", Font.BOLD , 30, Color.BLACK);
                        cartTitleContent.add(cartTitleLabel, BorderLayout.WEST); 
                        JLabel cartTitleButton = Utils.createIcon(30, 30, SwingConstants.CENTER, SwingConstants.CENTER, "trash.png");
                        
                        cartTitleButton.addMouseListener(new java.awt.event.MouseAdapter(){
        
                            @Override
                            public void mousePressed(java.awt.event.MouseEvent e) {
                                JOptionPane.showMessageDialog(null, "Will delete all items");
                            }
        
                        });
                
                        cartTitleContent.add(cartTitleButton, BorderLayout.EAST);
                //cashier details section (cashier name)
                JPanel cashierPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 30));
                cashierPanel.setBorder(border);
                cartTopSection.add(cashierPanel, BorderLayout.SOUTH);
                    JPanel cashierContent = Utils.createPanel(new BorderLayout(), new Dimension(500,30));
                    cashierContent.setBorder(spacer1);
                    cashierPanel.add(cashierContent, BorderLayout.CENTER);
                        JLabel cashierNameLabel = Utils.createLabel("Cashier Name: Jheoritch", Font.BOLD, 13, Color.BLACK);
                        cashierContent.add(cashierNameLabel, BorderLayout.WEST);
            
            //checkout center group (Items added to cart)
            cartCenterSection = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, 0, 2), new Dimension(440, 800));
            cartCenterSection.setBorder(spacer4);
            cartPanel.add(cartCenterSection, BorderLayout.CENTER);
            

            //checkout bottom group (Totals, taxes, Button etc.)
            JPanel cartTotalPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 200));
            cartPanel.add(cartTotalPanel, BorderLayout.SOUTH);
            
                //total group panel
                JPanel initialTotalPanel = Utils.createPanel(new GridLayout(3, 1), new Dimension(500, 120));
                initialTotalPanel.setBorder(spacer2);
                cartTotalPanel.add(initialTotalPanel, BorderLayout.NORTH);

                    //tax and subtotal Panels
                    JPanel discountPanel = Utils.createPanel(new BorderLayout(), new Dimension(460, 40));
                    discountPanel.setBorder(border);
                    initialTotalPanel.add(discountPanel);
                        JLabel discountLabel = Utils.createLabel("Tax: ", Font.BOLD , 15, Color.BLACK);
                        discountPanel.add(discountLabel, BorderLayout.WEST);
                        JLabel discountAmount = Utils.createLabel("$10", Font.BOLD , 15, Color.BLACK);
                        discountPanel.add(discountAmount, BorderLayout.EAST);
                    
                    JPanel taxPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 40));
                    taxPanel.setBorder(border);
                    initialTotalPanel.add(taxPanel);
                        JLabel taxLabel = Utils.createLabel("SubTotal: ", Font.BOLD , 15, Color.BLACK);
                        taxPanel.add(taxLabel, BorderLayout.WEST);
                        JLabel taxAmount = Utils.createLabel("$10", Font.BOLD , 15, Color.BLACK);
                        taxPanel.add(taxAmount, BorderLayout.EAST);
                    
                    JPanel subTotalPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 40));
                    subTotalPanel.setBorder(border);
                    initialTotalPanel.add(subTotalPanel);
                        JLabel subTotalLabel = Utils.createLabel("Discount: ", Font.BOLD , 15, Color.BLACK);
                        subTotalPanel.add(subTotalLabel, BorderLayout.WEST);
                        JLabel subTotalAmount = Utils.createLabel("$10", Font.BOLD , 15, Color.BLACK);     
                        subTotalPanel.add(subTotalAmount, BorderLayout.EAST);
                
                //check out button panel
                JPanel cartBtnPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 80));
                cartBtnPanel.setBorder(spacer3);
                cartTotalPanel.add(cartBtnPanel, BorderLayout.SOUTH);
                    JPanel cartBtnContent = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, 10, 10), new Dimension(460, 60), new Color(0xA2CA71));
                    cartBtnPanel.add(cartBtnContent, BorderLayout.CENTER);
                        JLabel checkoutLabel = Utils.createLabel("Checkout: ", Font.BOLD , 30, Color.BLACK);
                        cartBtnContent.add(checkoutLabel); 
                        JLabel checkoutAmount = Utils.createLabel("$1000", Font.BOLD , 30, Color.BLACK);
                        cartBtnContent.add(checkoutAmount);
                    
                    cartBtnContent.addMouseListener(new java.awt.event.MouseAdapter(){
                        @Override
                        public void mouseEntered(java.awt.event.MouseEvent e) {
                            cartBtnContent.setBackground(new Color(0x387F39)); // darker on hover
                        }
                        
                        @Override
                        public void mouseExited(java.awt.event.MouseEvent e) {
                            cartBtnContent.setBackground(new Color(0xA2CA71)); // back to normal
                        }
                        
                        @Override
                        public void mousePressed(java.awt.event.MouseEvent e) {
                            JOptionPane.showMessageDialog(null, "Will proceed to checkout");
                        }
                
                    });
                        
        //left side of frame (list of items, menu etc.)               
        JPanel itemsPanel = Utils.createPanel(new BorderLayout(), new Dimension(1420, 1080), new Color(0x387f39));
        frame.add(itemsPanel, BorderLayout.CENTER);
        
            // header panel
            JPanel headerPanel = Utils.createPanel(new BorderLayout(), new Dimension(1420, 50), new Color(0xA2CA71));
            headerPanel.setBorder(spacer1);
            itemsPanel.add(headerPanel, BorderLayout.NORTH);
            
                JLabel logoName = Utils.createIcon(150, 30, SwingConstants.CENTER, SwingConstants.CENTER, "logoName.png");
                headerPanel.add(logoName, BorderLayout.EAST);
            
                //Icons Panel for header Panel
                JPanel leftIcons = Utils.createPanel(new FlowLayout(FlowLayout.LEFT, 15, 10), new Dimension(90, 50));
                    JButton menuBurgerButton = Utils.createIconButton(30, 30, "menuBurgerIcon.png");
                    leftIcons.add(menuBurgerButton);                    
                    JButton settingsButton = Utils.createIconButton(30, 30, "settingsIcon.png");
                    leftIcons.add(settingsButton);
                    
                     //Button Functions
                    menuBurgerButton.addActionListener(e -> {
                        JOptionPane.showMessageDialog(null, "You have opened the menu!");
                    });
                    settingsButton.addActionListener(e -> {
                        JOptionPane.showMessageDialog(null, "You have opened the settings!");
                    });
                    
                headerPanel.add(leftIcons, BorderLayout.WEST);
        
            //add box panels for the items
            JPanel itemsListPanel = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, 30, 30), new Dimension(1420, 1030), new Color(0xF3F4F6));
            itemsPanel.add(itemsListPanel);
            
            //temporary items
            for (int i = 1; i <= 10; i++) {
            JButton btn = Utils.itemButton("Item " + i);

            int itemNumber = i;
            btn.addActionListener(e -> addToCart("Item " + itemNumber));
            
            itemsListPanel.add(btn);
            }
            
            //bottom section of lists
            JPanel bottomPanel = Utils.createPanel(new FlowLayout(FlowLayout.LEFT, 20, 10), new Dimension(1420, 50), new Color(0xA2CA71));
            itemsPanel.add(bottomPanel, BorderLayout.SOUTH);
                JButton searchButton = Utils.createIconButton(32, 32, "searchIcon.png");
                bottomPanel.add(searchButton);
                
                searchButton.addActionListener(e -> {
                    JOptionPane.showInputDialog(null, "Search specific item: ");
                });
        
                //HARDCODING CATEGORIES
                bottomPanel.add(Utils.createButtonLabel("Category 1", SwingConstants.CENTER, SwingConstants.CENTER));
                bottomPanel.add(Utils.createButtonLabel("Category 2", SwingConstants.CENTER, SwingConstants.CENTER));
                bottomPanel.add(Utils.createButtonLabel("Category 3", SwingConstants.CENTER, SwingConstants.CENTER));
        
        frame.setVisible(true);
    }
    
    private void addToCart(String itemName) {
    // Panel for one cart item (4 columns now: name, qty, price, delete btn)
    JPanel itemPanel = Utils.createPanel(new GridLayout(1, 4), new Dimension(400, 50));

    // Labels for the row
    JLabel nameLabel = new JLabel(itemName);
    JLabel quantityLabel = new JLabel("1");       
    JLabel priceLabel = new JLabel("$10.00");
    
    ImageIcon icon = new ImageIcon("cross-circle.png");
    Image img = icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    ImageIcon scaledIcon = new ImageIcon(img);
    
    Image hoverImg = icon.getImage().getScaledInstance(15, 15, Image.SCALE_SMOOTH);
    ImageIcon scaledHoverIcon = new ImageIcon(hoverImg);

    JButton deleteBtn = new JButton(scaledIcon);
    deleteBtn.setPreferredSize(new Dimension(20,20));
    deleteBtn.setBorderPainted(false);
    deleteBtn.setContentAreaFilled(false);
    deleteBtn.setFocusPainted(false);
    deleteBtn.setOpaque(false);

    // Align labels
    nameLabel.setHorizontalAlignment(SwingConstants.LEFT);
    quantityLabel.setHorizontalAlignment(SwingConstants.CENTER);
    priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
    deleteBtn.setHorizontalAlignment(SwingConstants.RIGHT);

    // Delete button action → remove its panel
    deleteBtn.addMouseListener(new java.awt.event.MouseAdapter(){
         
        @Override
        public void mouseEntered(java.awt.event.MouseEvent e) {
            deleteBtn.setIcon(scaledHoverIcon);
            cartCenterSection.revalidate();
            cartCenterSection.repaint();          
        }
        
        @Override
        public void mouseExited(java.awt.event.MouseEvent e) {
            deleteBtn.setIcon(scaledIcon);
        }
        
        @Override
        public void mousePressed(java.awt.event.MouseEvent e) {
            cartCenterSection.remove(itemPanel);
            cartCenterSection.revalidate();
            cartCenterSection.repaint();
        }
        
    });

    // Add to panel
    itemPanel.add(nameLabel);
    itemPanel.add(quantityLabel);
    itemPanel.add(priceLabel);
    itemPanel.add(deleteBtn);

    // Add item row to cart section
    cartCenterSection.add(itemPanel);

    // Refresh UI
    cartCenterSection.revalidate();
    cartCenterSection.repaint();
    }
    
    
}
