 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos.ui;

import com.mycompany.pos.config.AppConstants;
import com.mycompany.pos.config.UIColors;
import com.mycompany.pos.model.Item;
import java.awt.*;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.border.Border;

/**
 *
 * @author Khenyshi
 */
public class Utils {
    
    
    public static JPanel createPanel(LayoutManager layout, Dimension dim){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setOpaque(false);
        
        return panel;
    }
    
    public static JPanel createPanel(LayoutManager layout, Dimension dim, Color color){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setBackground(color);
        
        return panel;
    }
    
    public static JLabel createLabel(String text,int fontStroke, int fontSize, Color color) {
        JLabel label = new JLabel(text);  
        label.setFont(new Font("SansSerif", fontStroke, fontSize));
        label.setForeground(color);     
        
        return label;
    }
    
    public static JLabel createIcon(int width, int height, int hAlign, int vAlign, String resourcePath){
        ImageIcon icon = new ImageIcon(Utils.class.getResource(resourcePath));
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel label = new JLabel(scaledIcon, hAlign);
        label.setVerticalAlignment(vAlign);
        
        return label;
    }
    
    public static JButton createIconButton(int width, int height, String resourcePath) {
        ImageIcon icon = new ImageIcon(Utils.class.getResource(resourcePath));
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JButton button = new JButton();
        button.setIcon(scaledIcon);
        button.setPreferredSize(new Dimension(width, height));
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setVerticalAlignment(SwingConstants.CENTER);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBackground(Color.red);
        
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width - 3, height - 3, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }
            
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width + 2, height + 2, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }
        });

        return button;
    }  
    
    public static JLabel createButtonLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 20));
        label.setOpaque(true);
        label.setBackground(new Color(0xA2CA71));
        label.setForeground(Color.BLACK);
        label.setCursor(new Cursor(Cursor.HAND_CURSOR));
        label.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                label.setBackground(new Color(0x8AAC60));
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                label.setBackground(new Color(0x8AAC60));
                JOptionPane.showMessageDialog(null, "Changing items to " + text);
            }

            @Override
            public void mouseEntered(java.awt.event.MouseEvent e){
                label.setBackground(new Color(0x8AAC60));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e){
                label.setBackground(new Color(0xA2CA71));
            }
        });

        return label;
    }

    public static JTextField createTextField(String text) {
        JTextField textField = new JTextField(20);
        textField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        textField.setForeground(Color.BLACK);
        textField.setBackground(Color.WHITE);
        return textField;
     }
    
    public static JPanel createItemPanel(Item item) {
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(220, 170));
        panel.setBackground(new Color(0xA2CA71)); // base green color
        panel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        panel.setLayout(new BorderLayout());
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // --- Picture panel (with padding) ---
        JPanel picturePanel = new JPanel(new BorderLayout());
        picturePanel.setBackground(new Color(0xA2CA71));
        picturePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 5));

        Image scaledImage = item.getPicture()
                                .getImage()
                                .getScaledInstance(200, 120, Image.SCALE_SMOOTH);

        JLabel pictureLabel = new JLabel(new ImageIcon(scaledImage));
        pictureLabel.setHorizontalAlignment(JLabel.CENTER);
        pictureLabel.setVerticalAlignment(JLabel.CENTER);
        picturePanel.add(pictureLabel, BorderLayout.CENTER);

        // --- Prompt label (hover message) ---
        JLabel promptLabel = new JLabel("Add " + item.getName() + " to cart?");
        promptLabel.setHorizontalAlignment(JLabel.CENTER);
        promptLabel.setVerticalAlignment(JLabel.CENTER);
        promptLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        promptLabel.setForeground(Color.BLACK);

        // --- Container that switches between picture and prompt ---
        JPanel centerContainer = new JPanel(new CardLayout());
        centerContainer.setBackground(new Color(0xA2CA71));
        centerContainer.add(picturePanel, "PICTURE");
        centerContainer.add(promptLabel, "PROMPT");

        panel.add(centerContainer, BorderLayout.CENTER);

        // --- Bottom name panel ---
        JPanel namePanel = Utils.createPanel(
            new BorderLayout(),
            new Dimension(220, 40),
            new Color(0xA2CA71)
        );

        JLabel nameLabel = new JLabel(item.getName());
        nameLabel.setHorizontalAlignment(JLabel.CENTER);
        nameLabel.setVerticalAlignment(JLabel.CENTER);
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        nameLabel.setForeground(Color.BLACK);
        namePanel.add(nameLabel, BorderLayout.CENTER);

        panel.add(namePanel, BorderLayout.SOUTH);

        // --- Hover behavior ---
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                ((CardLayout) centerContainer.getLayout()).show(centerContainer, "PROMPT");
                namePanel.setVisible(false);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                ((CardLayout) centerContainer.getLayout()).show(centerContainer, "PICTURE");
                namePanel.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                centerContainer.setBackground(new Color(0x8AAC60));
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                centerContainer.setBackground(new Color(0xA2CA71));
            }
        });

        return panel;
    }
}
