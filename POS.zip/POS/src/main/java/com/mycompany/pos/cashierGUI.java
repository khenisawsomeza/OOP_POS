/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Khenyshi
 */
public class cashierGUI extends JFrame {
    JFrame frame = new JFrame();
    
    public cashierGUI(){
        frame.setSize(1280, 720);
        frame.setMinimumSize(new Dimension(1280, 720));
        frame.setMaximumSize(new Dimension(1920, 1080));   
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Cashier");
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        
        //checkout panel (right)
        JPanel rightPanel = Utils.createPanel( new BorderLayout(), new Dimension(500, 1080), new Color(0xF3F4F6));
        frame.add(rightPanel, BorderLayout.EAST);
        
            //checkout top group (top)
            JPanel checkTopPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 100), new Color(0x387F39));
            rightPanel.add(checkTopPanel, BorderLayout.NORTH);
            
            //checkout bottom group (bottom)
            JPanel checkBottomPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 250));
            rightPanel.add(checkBottomPanel, BorderLayout.SOUTH);
                
                //total group 
                JPanel dataPanel = Utils.createPanel(new GridLayout(), new Dimension(500, 150));
                checkBottomPanel.add(dataPanel, BorderLayout.NORTH);
                
                //check out button panel
                JPanel btnPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 100), new Color(0x387F39));
                checkBottomPanel.add(btnPanel, BorderLayout.SOUTH);
        
        //items panel (left)
        JPanel leftPanel = Utils.createPanel(new BorderLayout(), new Dimension(1420,1080), new Color(0x387F39));
        frame.add(leftPanel, BorderLayout.CENTER);
        
         
        
        
        
        frame.setVisible(true);
    }
    
    
}
