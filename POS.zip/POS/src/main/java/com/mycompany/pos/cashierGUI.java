/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

/**
 *
 * @author Khenyshi
 */
public class cashierGUI extends JFrame {
    JFrame frame = new JFrame();
    
    public cashierGUI(){
        frame.setSize(1280, 720);
        frame.setMinimumSize(new Dimension(1280, 720));
        frame.setMaximumSize(new Dimension(1920, 1080));   
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Cashier");
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        
        Border border = BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK);
        
        //right side of frame (checkout and cart group)
        JPanel rightPanel = Utils.createPanel( new BorderLayout(), new Dimension(500, 1080), new Color(0xF3F4F6));       
        
            //checkout top group (Headers)
            JPanel checkTopPanel = Utils.createPanel(new GridLayout(2,1), new Dimension(500, 100));
                JPanel headerPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 50));
                headerPanel.setBorder(border);
                    JPanel headerLeftMargin = Utils.createPanel(new FlowLayout(), new Dimension(10, 50));
                    JPanel headerContentPanel = Utils.createPanel(new GridLayout(), new Dimension(480, 50));
                        JLabel cartLabel = Utils.createLabel("Cart", 20, SwingConstants.LEFT, SwingConstants.CENTER);
                        JLabel deleteAllBtn = Utils.createLabel("Delete", 20, SwingConstants.RIGHT, SwingConstants.CENTER);
                    JPanel headerRightMargin = Utils.createPanel(new FlowLayout(), new Dimension(10, 50));
                            
                JPanel cashierNamePanel = Utils.createPanel(new BorderLayout(10, 10), new Dimension(500, 50));
                    JPanel cashierLeftMargin = Utils.createPanel(new FlowLayout(), new Dimension(10, 50));
                    JLabel cashierName = Utils.createLabel("Cashier Name: Jheoritch", 12, SwingConstants.LEFT, SwingConstants.CENTER);
            
            //checkout center group (Items added to cart)
            JPanel checkCenterPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 730), Color.BLACK);           
            
            //checkout bottom group (Totals, taxes, Button etc.)
            JPanel checkBottomPanel = Utils.createPanel(new BorderLayout(), new Dimension(500, 250));          
                
                //total group panel
                JPanel dataPanel = Utils.createPanel(new GridLayout(2,1), new Dimension(500, 100));              
                
                    //tax and subtotal Panels
                    JPanel subTotalPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 50));
                            
                    JPanel taxPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 50));
                                  
                //check out button panel
                JPanel btnPanel = Utils.createPanel(new FlowLayout(), new Dimension(500, 150), new Color(0x387F39));
                
        
        //left side of frame (items, navigation etc.)
        JPanel leftPanel = Utils.createPanel(new BorderLayout(), new Dimension(1420,1080), new Color(0x387F39));
             
        frame.add(rightPanel, BorderLayout.EAST);
            rightPanel.add(checkTopPanel, BorderLayout.NORTH);
                checkTopPanel.add(headerPanel);
                    headerPanel.add(headerLeftMargin, BorderLayout.WEST);
                    headerPanel.add(headerContentPanel, BorderLayout.CENTER);                  
                        headerContentPanel.add(cartLabel);                  
                        headerContentPanel.add(deleteAllBtn);                  
                    headerPanel.add(headerRightMargin, BorderLayout.EAST);
                checkTopPanel.add(cashierNamePanel);
                    cashierNamePanel.add(cashierLeftMargin, BorderLayout.WEST);
                    cashierNamePanel.add(cashierName, BorderLayout.CENTER);
            rightPanel.add(checkCenterPanel, BorderLayout.CENTER);
            rightPanel.add(checkBottomPanel, BorderLayout.SOUTH);
                checkBottomPanel.add(dataPanel, BorderLayout.NORTH);
                    dataPanel.add(subTotalPanel);
                    dataPanel.add(taxPanel);
                checkBottomPanel.add(btnPanel, BorderLayout.SOUTH);
        frame.add(leftPanel, BorderLayout.CENTER);
        
        
        
        frame.setVisible(true);
    }
    
    
}
