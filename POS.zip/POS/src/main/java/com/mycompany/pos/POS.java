/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pos;

import com.mycompany.pos.ui.cashierGUI;

public class POS {

    public static void main(String[] args) {
        cashierGUI cashierGUI = new cashierGUI();
    }
}
