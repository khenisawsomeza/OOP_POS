package com.mycompany.pos.config;

import java.awt.Color;

public class UIColors {
    
    // Primary Colors
    public static final Color PRIMARY_GREEN = new Color(0x387f39);
    public static final Color LIGHT_GREEN = new Color(0xA2CA71);
    public static final Color LIGHT_GRAY = new Color(0xF3F4F6);
    public static final Color WHITE = Color.WHITE;
    
    // Item Button Colors
    public static final Color ITEM_BUTTON_NORMAL = new Color(0xf6e96b);
    public static final Color ITEM_BUTTON_HOVER = new Color(0xf7d83b);
    public static final Color ITEM_BUTTON_PRESSED = new Color(0xf4c20d);
    
    // Checkout Button Colors
    public static final Color CHECKOUT_NORMAL = new Color(0xA2CA71);
    public static final Color CHECKOUT_HOVER = new Color(0x387F39);
    
    // Border and Text Colors
    public static final Color BORDER_GRAY = new Color(0x808080);
    public static final Color TEXT_BLACK = Color.BLACK;
    public static final Color TEXT_WHITE = Color.WHITE;
    
    // Background Colors
    public static final Color CART_BACKGROUND = new Color(0xF3F4F6);
    public static final Color ITEMS_BACKGROUND = new Color(0x387f39);
    public static final Color HEADER_BACKGROUND = new Color(0xA2CA71);
    public static final Color ITEMS_LIST_BACKGROUND = new Color(0xF3F4F6);
    
    // Transparent
    public static final Color TRANSPARENT = new Color(0, 0, 0, 0);
}
