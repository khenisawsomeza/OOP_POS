package com.mycompany.pos.ui.cashier.components;

import com.mycompany.pos.config.*;
import com.mycompany.pos.model.*;
import com.mycompany.pos.ui.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

public class CartPanel extends JPanel {
    private Cart cart;
    private JPanel cartItemsSection;
    private JLabel taxAmountLabel;
    private JLabel subtotalAmountLabel;
    private JLabel discountAmountLabel;
    private JLabel checkoutAmountLabel;
    
    public CartPanel(Cart cart) {
        this.cart = cart;
        initializeCartPanel();
    }
    
    //Initialize the cart panel with all sections
    private void initializeCartPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_PANEL_HEIGHT));
        setBackground(UIColors.CART_BACKGROUND);
        setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, UIColors.BORDER_GRAY));
        
        // Add cart sections
        addCartTopSection();
        addCartCenterSection();
        addCartBottomSection();
    }
    
    /**
     * Create and add the cart top section (title and cashier info)
    **/
    private void addCartTopSection() {
        JPanel cartTopSection = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_TOP_HEIGHT));
        add(cartTopSection, BorderLayout.NORTH);
        
        // Cart title section
        addCartTitleSection(cartTopSection);
        
        // Cashier info section
        addCashierSection(cartTopSection);
    }
    
        //Create cart title section with trash button
        private void addCartTitleSection(JPanel parent) {
            JPanel cartTitlePanel = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_TITLE_HEIGHT));
            cartTitlePanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIColors.BORDER_GRAY));
            parent.add(cartTitlePanel, BorderLayout.NORTH);

            JPanel cartTitleContent = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_TITLE_HEIGHT));
            cartTitleContent.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
            cartTitlePanel.add(cartTitleContent, BorderLayout.CENTER);

            // Cart title
            JLabel cartHeaderLabel = Utils.createLabel("Cart", Font.BOLD, AppConstants.TITLE_FONT_SIZE, UIColors.TEXT_BLACK);
            cartTitleContent.add(cartHeaderLabel, BorderLayout.WEST);

            JButton clearAllItemsButton = Utils.createIconButton(AppConstants.MEDIUM_ICON_SIZE, AppConstants.MEDIUM_ICON_SIZE,AppConstants.TRASH_ICON);

            clearAllItemsButton.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mousePressed(java.awt.event.MouseEvent e) {
                    handleClearCart();
                }
                
            });
            cartTitleContent.add(clearAllItemsButton, BorderLayout.EAST);
        }
        
            // Handle clear cart action
            private void handleClearCart() {
                int result = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to clear all items from the cart?",
                    "Clear Cart",
                    JOptionPane.YES_NO_OPTION
                );

                if (result == JOptionPane.YES_OPTION) {
                    cart.clearCart();
                    refreshCartDisplay();
                }
            }

        //Create cashier info section
        private void addCashierSection(JPanel parent) {
            JPanel cashierPanel = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CASHIER_SECTION_HEIGHT));
            cashierPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIColors.BORDER_GRAY));
            parent.add(cashierPanel, BorderLayout.SOUTH);

            JPanel cashierContent = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CASHIER_SECTION_HEIGHT));
            cashierContent.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
            cashierPanel.add(cashierContent, BorderLayout.CENTER);

            JLabel cashierNameLabel = Utils.createLabel("Cashier Name: " + AppConstants.DEFAULT_CASHIER_NAME, Font.BOLD, AppConstants.SMALL_FONT_SIZE, UIColors.TEXT_BLACK);
            cashierContent.add(cashierNameLabel, BorderLayout.WEST);
        }
    
    /**
     * Create and add cart center section (items list)
    **/    
    private void addCartCenterSection() { 
        cartItemsSection = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, 0, 10), new Dimension(AppConstants.CART_CENTER_WIDTH, AppConstants.CART_CENTER_HEIGHT));
        cartItemsSection.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        add(cartItemsSection, BorderLayout.CENTER);
    }
    
        //Create a panel for displaying a cart item
        private JPanel createCartItemPanel(Item item, int quantity) {
            JPanel cartItemRowPanel = Utils.createPanel(new GridLayout(1, 4), new Dimension(400, 50), UIColors.WHITE);

            cartItemRowPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            // Item details
            JLabel itemNameLabel = Utils.createLabel(item.getName(), Font.BOLD, 14, UIColors.TEXT_BLACK);
            itemNameLabel.setHorizontalAlignment(SwingConstants.LEFT);

            JLabel itemQuantityLabel = Utils.createLabel(String.valueOf(quantity), Font.BOLD, 14, UIColors.TEXT_BLACK);
            itemQuantityLabel.setHorizontalAlignment(SwingConstants.CENTER);

            JLabel itemPriceLabel = Utils.createLabel(item.getFormattedPrice(), Font.BOLD, 14, UIColors.TEXT_BLACK);
            itemPriceLabel.setHorizontalAlignment(SwingConstants.CENTER);

            // Delete button
            JButton removeItemButton = createDeleteButton(item);

            // Add components to panel
            cartItemRowPanel.add(itemNameLabel);
            cartItemRowPanel.add(itemQuantityLabel);
            cartItemRowPanel.add(itemPriceLabel);
            cartItemRowPanel.add(removeItemButton);

            return cartItemRowPanel;
        }
        
            //Create delete button for cart item
            private JButton createDeleteButton(Item item) {

                JButton removeItemButton = Utils.createIconButton(15, 15, AppConstants.DELETE_ICON);
                removeItemButton.setHorizontalAlignment(SwingConstants.RIGHT);

                // Delete button hover function
                removeItemButton.addMouseListener(new java.awt.event.MouseAdapter() {

                    @Override
                    public void mousePressed(java.awt.event.MouseEvent e) {
                        cart.removeItemCompletely(item);
                        refreshCartDisplay();
                    }
                });

                return removeItemButton;
            }
    
    //Create and add cart bottom section (totals and checkout)
    private void addCartBottomSection() {
        JPanel cartTotalPanel = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_TOTAL_HEIGHT));
        add(cartTotalPanel, BorderLayout.SOUTH);
        
        // Add totals section
        addTotalsSection(cartTotalPanel);
        
        // Add checkout button
        addCheckoutButton(cartTotalPanel);
    }
    
        //Create totals section (tax, subtotal, discount)
        private void addTotalsSection(JPanel parent) {
            JPanel initialTotalPanel = Utils.createPanel(new GridLayout(3, 1), new Dimension(AppConstants.CART_PANEL_WIDTH, 120));
            initialTotalPanel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
            parent.add(initialTotalPanel, BorderLayout.NORTH);

            // Tax panel
            JPanel taxPanel = createTotalRow("Tax: ", AppConstants.SAMPLE_TAX);
            taxAmountLabel = (JLabel)taxPanel.getComponent(1); // Get the amount label
            initialTotalPanel.add(taxPanel);

            // Subtotal panel
            JPanel subtotalPanel = createTotalRow("SubTotal: ", AppConstants.SAMPLE_SUBTOTAL);
            subtotalAmountLabel = (JLabel) subtotalPanel.getComponent(1);
            initialTotalPanel.add(subtotalPanel);

            // Discount panel
            JPanel discountPanel = createTotalRow("Discount: ", AppConstants.SAMPLE_DISCOUNT);
            discountAmountLabel = (JLabel) discountPanel.getComponent(1);
            initialTotalPanel.add(discountPanel);
        }
        
            //Create a row for totals display (label and amount)
            private JPanel createTotalRow(String labelText, String amountText) {
                JPanel rowPanel = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, 40));
                rowPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIColors.BORDER_GRAY));

                JLabel label = Utils.createLabel(labelText, Font.BOLD, AppConstants.REGULAR_FONT_SIZE, UIColors.TEXT_BLACK);
                rowPanel.add(label, BorderLayout.WEST);

                JLabel amount = Utils.createLabel(amountText, Font.BOLD, AppConstants.REGULAR_FONT_SIZE, UIColors.TEXT_BLACK);
                rowPanel.add(amount, BorderLayout.EAST);

                return rowPanel;
            }

        //Create checkout button section
        private void addCheckoutButton(JPanel parent) {

            JPanel checkoutButtonPanel = Utils.createPanel(new BorderLayout(), new Dimension(AppConstants.CART_PANEL_WIDTH, AppConstants.CART_BUTTON_HEIGHT));
            checkoutButtonPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
            parent.add(checkoutButtonPanel, BorderLayout.SOUTH);

            JPanel checkoutButtonContent = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, 10, 10), new Dimension(460, 60), UIColors.CHECKOUT_NORMAL);
            checkoutButtonPanel.add(checkoutButtonContent, BorderLayout.CENTER);

            JLabel checkoutTitleLabel = Utils.createLabel("Checkout: ", Font.BOLD, AppConstants.TITLE_FONT_SIZE, UIColors.TEXT_BLACK);
            checkoutButtonContent.add(checkoutTitleLabel);

            checkoutAmountLabel = Utils.createLabel(AppConstants.SAMPLE_CHECKOUT_TOTAL, Font.BOLD, AppConstants.TITLE_FONT_SIZE, UIColors.TEXT_BLACK);
            checkoutButtonContent.add(checkoutAmountLabel);

            // Checkout button hover and click effects
            checkoutButtonContent.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent e) {
                    checkoutButtonContent.setBackground(UIColors.CHECKOUT_HOVER);
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent e) {
                    checkoutButtonContent.setBackground(UIColors.CHECKOUT_NORMAL);
                }

                @Override
                public void mousePressed(java.awt.event.MouseEvent e) {
                    handleCheckout();
                }
            });
        }
    

    //Handle checkout action
    private void handleCheckout() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cart is empty! Add items before checkout.");
            return;
        }
        
        JOptionPane.showMessageDialog(this, "Processing checkout for: " + cart.getFormattedTotal());
    }
    
    //Refresh the cart display with current cart contents
    public void refreshCartDisplay() {
    // Clear current cart items display
    cartItemsSection.removeAll();

    // Add current cart items
    for (CartEntry entry : cart.getItems()) {
        JPanel itemPanel = createCartItemPanel(entry.getItem(), entry.getQuantity());
        cartItemsSection.add(itemPanel);
    }

    // Update totals
        updateTotalsDisplay();

        // Refresh UI
        cartItemsSection.revalidate();
        cartItemsSection.repaint();
    }
   
    //Update the totals display with current cart values
    private void updateTotalsDisplay() {
        if (taxAmountLabel != null) {
            taxAmountLabel.setText(cart.getFormattedTaxAmount());
        }
        if (subtotalAmountLabel != null) {
            subtotalAmountLabel.setText(cart.getFormattedSubtotal());
        }
        if (discountAmountLabel != null) {
            discountAmountLabel.setText(cart.getFormattedDiscount());
        }
        if (checkoutAmountLabel != null) {
            checkoutAmountLabel.setText(cart.getFormattedTotal());
        }
    }
}
