package com.mycompany.pos.ui.cashier.components;

import com.mycompany.pos.config.AppConstants;
import com.mycompany.pos.config.UIColors;
import com.mycompany.pos.model.Cart;
import com.mycompany.pos.model.Item;
import com.mycompany.pos.ui.Utils;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class ItemsPanel extends JPanel {
    private Cart cart;
    private CartPanel cartPanel;
    private List<Item> availableItems;
    private JPanel itemsListPanel;
    
    public ItemsPanel(Cart cart, CartPanel cartPanel) {
        this.cart = cart;
        this.cartPanel = cartPanel;
        this.availableItems = createSampleItems(); //for showing only (to be changed to retrieve data from MySQL)
        initializeItemsPanel();
    }
    
    //Initialize the items panel with header, items grid, and bottom controls
    private void initializeItemsPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(AppConstants.ITEMS_PANEL_WIDTH, AppConstants.ITEMS_PANEL_HEIGHT));
        setBackground(UIColors.ITEMS_BACKGROUND);
        
        // Add header
        add(new HeaderPanel(), BorderLayout.NORTH);
        
        // Add items grid
        addItemsGrid();
        
        // Add bottom controls
        addBottomControls();
    }
    
    // Create and add the items grid section
    private void addItemsGrid() {
        itemsListPanel = Utils.createPanel(new FlowLayout(FlowLayout.CENTER, AppConstants.ITEM_GRID_GAP, AppConstants.ITEM_GRID_GAP), new Dimension(AppConstants.ITEMS_PANEL_WIDTH, AppConstants.ITEMS_PANEL_HEIGHT), UIColors.ITEMS_LIST_BACKGROUND);
        
        // Add item buttons
        refreshItemsDisplay();
        
        add(itemsListPanel, BorderLayout.CENTER);
    }
    
    //Refresh the items display based on current available items
        private void refreshItemsDisplay() {
            itemsListPanel.removeAll();

            for (Item item : availableItems) {
                JPanel itemButton = Utils.createItemPanel(item);
                
                itemButton.addMouseListener(new java.awt.event.MouseAdapter(){
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        handleItemClick(item);
                    }
                });
                itemsListPanel.add(itemButton);
            }
            
            itemsListPanel.revalidate();
            itemsListPanel.repaint();
        }
    
    //Create and add bottom controls (search and categories)
    private void addBottomControls() {
        JPanel bottomControlsPanel = Utils.createPanel(new BorderLayout(), new Dimension(1420, 50), new Color(0xA2CA71));   
        // Category buttons
        JPanel buttonsPanel = Utils.createPanel(new FlowLayout(FlowLayout.LEFT, 20, 0), null, new Color(0xA2CA71));

        buttonsPanel.setMaximumSize(new Dimension(500, 50));

        buttonsPanel.add(Utils.createButtonLabel("Entree"));
        buttonsPanel.add(Utils.createButtonLabel("Dessert"));
        buttonsPanel.add(Utils.createButtonLabel("Beverages"));

        bottomControlsPanel.add(buttonsPanel, BorderLayout.CENTER);
        
        add(bottomControlsPanel, BorderLayout.SOUTH);
    }
    
    //Handle item button click - add to cart
    private void handleItemClick(Item item) {
        cart.addItem(item);
        cartPanel.refreshCartDisplay();
    }
    
    //Handle search button click
    private void handleSearchClick() {
        String searchTerm = JOptionPane.showInputDialog(this, "Search specific item: ");
        if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            // TODO: Implement actual search functionality
            System.out.println("Searching for: " + searchTerm);
        }
    }
    
    /**
     * Create sample items for demonstration
     * TODO: Replace with actual item loading from database/file
     */
    private List<Item> createSampleItems() {                
            ArrayList<Item> entrees = new ArrayList<>();
            Item newItem1 = new Item("1", "Pizza", 450, "");
            Item newItem2 = new Item("2", "Rissoto", 600, "");
            Item newItem3 = new Item("3", "Lasagna", 350, "");
            Item newItem4 = new Item("4", "Gnocchi", 400, "");
            Item newItem5 = new Item("5", "Bruschetta", 200, "");
            Item newItem6 = new Item("6", "Calzone", 500, "");
            Item newItem7 = new Item("7", "Frittata", 320, "");
            Item newItem8 = new Item("8", "Polenta", 380, "" );
            entrees.add(newItem1);
            entrees.add(newItem2);
            entrees.add(newItem3);
            entrees.add(newItem4);
            entrees.add(newItem5);
            entrees.add(newItem6);
            entrees.add(newItem7);
            entrees.add(newItem8);
            
       
        return entrees;
    } 
}
