 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Khenyshi
 */
public class Utils {
    
    public static JPanel createPanel(LayoutManager layout, Dimension dim){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setOpaque(false);
        
        return panel;
    }
    
     public static JPanel createPanel(LayoutManager layout, Dimension dim, Color color){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setBackground(color);
        
        return panel;
    }
     
    public static JLabel createLabel(String text, int fontSize, int hAlign, int vAlign) {
    JLabel label = new JLabel(text, hAlign);   // horizontal alignment
    label.setFont(new Font("Arial", Font.BOLD, fontSize));
    label.setVerticalAlignment(vAlign);        // vertical alignment
    return label;
    }
    
    
}
