 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pos;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

/**
 *
 * @author Khenyshi
 */
public class Utils {
    
    
    public static JPanel createPanel(LayoutManager layout, Dimension dim){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setOpaque(false);
        
        return panel;
    }
    
    public static JPanel createPanel(LayoutManager layout, Dimension dim, Color color){
                
        JPanel panel = new JPanel(layout);
        panel.setPreferredSize(dim);
        panel.setBackground(color);
        
        return panel;
    }
    
    public static JLabel createLabel(String text,int fontStroke, int fontSize, Color color) {
        JLabel label = new JLabel(text);  
        label.setFont(new Font("SansSerif", fontStroke, fontSize));
        label.setForeground(color);     
        
        return label;
    }
    
    public static Border createSpacer(int top, int left, int bottom, int right){
        Border border = BorderFactory.createEmptyBorder(top, left, bottom, right);
        
        return border;
    }
    
    public static JLabel createIcon(int width, int height, int hAlign, int vAlign, String file){
        ImageIcon icon = new ImageIcon(file);
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel label = new JLabel(scaledIcon, hAlign);
        label.setVerticalAlignment(vAlign);
        
        return label;
    }
    
    public static JButton createIconButton(int width, int height, String file) {
        ImageIcon icon = new ImageIcon(file);

        JButton button = new JButton();
        button.setIcon(icon);
        button.setPreferredSize(new Dimension(width, height));
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setVerticalAlignment(SwingConstants.CENTER);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width - 3, height - 3, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                button.setIcon(new ImageIcon(img));
            }
        });

        return button;
    }
    
    public static JButton itemButton(String subCategoryName) {
        JButton button = new JButton(subCategoryName);
        button.setPreferredSize(new Dimension(150, 100));
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setVerticalAlignment(SwingConstants.CENTER);

        button.setBackground(new Color(0xf6e96b));
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);    

        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(new Color(0xf7d83b)); // darker on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(new Color(0xf6e96b)); // back to normal
            }

            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                button.setBackground(new Color(0xf4c20d)); // even darker when clicked
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                button.setBackground(new Color(0xf7d83b)); // return to hover color
            }
        });
        
        return button;
    }
    
    public static JLabel createButtonLabel(String text, int hAlign, int vAlign) {
        JLabel label = new JLabel(text, hAlign);
        label.setFont(new Font("SansSerif", Font.BOLD, 20));
        label.setPreferredSize(new Dimension(110, 30));
        label.setVerticalAlignment(vAlign);
        label.setCursor(new Cursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                label.setFont(new Font("SansSerif", Font.BOLD, 15));
                System.out.println(text + " clicked!");
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                label.setFont(new Font("SansSerif", Font.BOLD, 20));
                JOptionPane.showMessageDialog(null, "Changing items to " + text);

            }
        });

        return label;
    }
}
