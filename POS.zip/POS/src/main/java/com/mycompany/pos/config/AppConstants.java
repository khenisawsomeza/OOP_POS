package com.mycompany.pos.config;

import java.awt.*;

public class AppConstants {
    
    static final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    
    // Window Settings
    public static final int WINDOW_WIDTH = screenSize.width;
    public static final int WINDOW_HEIGHT = screenSize.height;
    public static final int MIN_WINDOW_WIDTH = 1280;
    public static final int MIN_WINDOW_HEIGHT = 720;
    public static final int MAX_WINDOW_WIDTH = screenSize.width;
    public static final int MAX_WINDOW_HEIGHT = screenSize.height;
    public static final String APP_TITLE = "Cashier";
    
    // Panel Dimensions
    public static final int CART_PANEL_WIDTH = 500;
    public static final int CART_PANEL_HEIGHT = Integer.MAX_VALUE;
    public static final int ITEMS_PANEL_WIDTH = 780; //will adjust (CENTERED BORDER LAYOUT)
    public static final int ITEMS_PANEL_HEIGHT = Integer.MAX_VALUE;
    public static final int HEADER_HEIGHT = 50;
    
    // Cart Section Dimensions
    public static final int CART_TOP_HEIGHT = 80;
    public static final int CART_TITLE_HEIGHT = 50;
    public static final int CASHIER_SECTION_HEIGHT = 30;
    public static final int CART_CENTER_WIDTH = Integer.MAX_VALUE;
    public static final int CART_CENTER_HEIGHT = 800;
    public static final int CART_TOTAL_HEIGHT = 200;
    public static final int CART_BUTTON_HEIGHT = 80;
    
    // Item Button Settings
    public static final int ITEM_BUTTON_WIDTH = 150;
    public static final int ITEM_BUTTON_HEIGHT = 100;
    public static final int ITEM_GRID_GAP = 30;
    
    // Icon Sizes
    public static final int SMALL_ICON_SIZE = 20;
    public static final int MEDIUM_ICON_SIZE = 30;
    public static final int LARGE_ICON_SIZE = 32;
    public static final int LOGO_WIDTH = 150;
    public static final int LOGO_HEIGHT = 30;
    
    // Font Settings
    public static final String DEFAULT_FONT = "SansSerif";
    public static final int TITLE_FONT_SIZE = 30;
    public static final int SUBTITLE_FONT_SIZE = 20;
    public static final int REGULAR_FONT_SIZE = 15;
    public static final int SMALL_FONT_SIZE = 13;
    public static final int BUTTON_FONT_SIZE = 16;
    
    // Sample Data
    public static final String DEFAULT_CASHIER_NAME = "Jheoritch";
    public static final String SAMPLE_PRICE = "$10.00";
    public static final String SAMPLE_TAX = "$10";
    public static final String SAMPLE_SUBTOTAL = "$10";
    public static final String SAMPLE_DISCOUNT = "$10";
    public static final String SAMPLE_CHECKOUT_TOTAL = "$1000";
    public static final int DEFAULT_QUANTITY = 1;
    public static final int SAMPLE_ITEM_COUNT = 10;
    
    // Image Paths
    public static final String IMAGES_PATH = "/images/icons/";
    public static final String LOGO_IMAGE = IMAGES_PATH + "logoName.png";
    public static final String MENU_ICON = IMAGES_PATH + "menuBurgerIcon.png";
    public static final String SETTINGS_ICON = IMAGES_PATH + "settingsIcon.png";
    public static final String SEARCH_ICON = IMAGES_PATH + "searchIcon.png";
    public static final String TRASH_ICON = IMAGES_PATH + "trash.png";
    public static final String DELETE_ICON = IMAGES_PATH + "cross-circle.png";
    public static final String USER_ICON = IMAGES_PATH + "user.png";
    
    // Category Names
    public static final String[] DEFAULT_CATEGORIES = {"Category 1", "Category 2", "Category 3"};
}
